A Pen created at CodePen.io. You can find this one at http://codepen.io/anon/pen/MbJrPY.

 Fixed table header with simple jQuery code..